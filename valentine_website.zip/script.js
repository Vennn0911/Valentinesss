function showLove() {
    alert('Yay! Can’t wait to celebrate Valentine’s Day with you! ❤️');
}
